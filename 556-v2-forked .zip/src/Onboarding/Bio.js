import React, { useRef, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { db } from "../Firebase";
import { Form, Alert, Button } from "react-bootstrap";
import { Link, useHistory } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function Bio() {
  const { currentUser } = useAuth();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const history = useHistory();
  const nameRef = useRef();
  // const dateRef = useRef();
  const genderRef = useRef();
  const legal = new Date();
  const now = new Date();
  legal.setFullYear(legal.getFullYear() - 18);
  const [setDate, setSelectedDate] = useState(legal);

  async function handleSubmit(e) {
    e.preventDefault();
    const data = {
      name: nameRef.current.value,
      birthday: setDate,
      age: now.getFullYear() - legal.getFullYear(),
      gender: genderRef.current.value
    };

    const email = currentUser.email;

    setError("");
    setLoading(true);
    await db
      .collection("users")
      .doc(email)
      .set(data)
      .then(() => {
        history.push("home");
      })
      .catch((error) => {
        setError("Failed to update bio");
      });
    setLoading(false);
  }

  return (
    <div>
      <div className="main_box--main--signUp">
        <h2 className="text-center mb-4">Some More Info</h2>
        {error && <Alert variant="danger">{error}</Alert>}
        <Form onSubmit={handleSubmit}>
          <Form.Group id="bioName">
            <Form.Label> First Name </Form.Label>
            <Form.Control type="text" ref={nameRef} required />
          </Form.Group>
          <Form.Group id="bioGender">
            <Form.Label> Gender </Form.Label>
            <Form.Control as="select" mulitple ref={genderRef} required>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </Form.Control>
          </Form.Group>
          <Form.Group id="bioDOB">
            <Form.Label> Birthday </Form.Label>
            <DatePicker
              selected={setDate}
              onChange={(date) => setSelectedDate(date)}
              maxDate={legal}
              isClearable
              showYearDropdown
              scrollableMonthYearDropdown
            />
          </Form.Group>
          <Button
            // disabled={loading}
            className="btnn btnn-success"
            type="submit"
          >
            Submit
          </Button>
        </Form>
        {/* <div className="w-100 text-center mt-2">
          Don't have an account? <Link to="/signup">Sign Up</Link>
        </div> */}
      </div>
    </div>
  );
}
