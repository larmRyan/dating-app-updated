import React from "react";
import Chat from "./Chat";

export default function Chats() {

  return (
    <div className="chats">
      <Chat
        name="Christina"
        message="*New Connection*"
        timestamp="20 min ago"
        profilePic="https://diy-magazine.s3.amazonaws.com/d/diy/Artists/G/Girl-In-red/_landscape/188378/Girl-in-Red_-by-Chris-Almeida-1.jpg"
      />

    </div>
  );
}