import React from "react";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import "./Header.css";
import IconButton from "@material-ui/core/IconButton";
import { Link, useHistory } from "react-router-dom";

export default function Logout() {
  return (
    <div className="logout">
      <Link to="/log">
        <h3>Logout</h3>
      </Link>
    </div>
  );
}
