import React from "react";
import "./TwoTruthsOneLie.css";

class TwoTruthsOneLie extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      truth1: "",
      truth2: "",
      lie: ""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // TODO: redirect or render new HTML?
  handleSubmit(event) {
    event.preventDefault();

    // set state is async and doesn't show updates in console immediately unless
    // the log is written like this
    this.setState(
      {
        truth1: event.target.truth1.value,
        truth2: event.target.truth2.value,
        lie: event.target.lie.value
      },
      () => console.log(this.state)
    );

    // db.collection(users).doc(user).update({
    //   ttol: {
    //     truth1: this.state.truth1,
    //     truth2: this.state.truth2,
    //     lie: this.state.lie
    //   }
    // });
  }

  // TODO: put in redirect here
  render() {
    return (
      <div>
        <form className="TwoTruthsOneLie" onSubmit={this.handleSubmit}>
          <ul>
            <li className="form-row truth">
              <input id="truth1" type="text" name="truth1" />
              <label htmlFor="truth1">First Truth</label>
            </li>

            <li className="form-row truth">
              <input id="truth2" type="text" name="truth2" />
              <label htmlFor="truth2">Second Truth</label>
            </li>

            <li className="form-row lie">
              <label htmlFor="lie">Lie</label>
              <input id="lie" type="text" name="lie" />
            </li>

            <li className="form-row">
              <input type="submit" value="Send" />
            </li>
          </ul>
        </form>
      </div>
    );
  }
}

export default TwoTruthsOneLie;
