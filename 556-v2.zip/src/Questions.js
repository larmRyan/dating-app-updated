import React from "react";
import "./Questions.css";
import { AuthProvider, useAuth } from "./contexts/AuthContext";

class Questions extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      first: "",
      first_id: "",
      second: "",
      second_id: ""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onClick = this.onClick.bind(this);
  }

  onChange(event) {
    if (this.state.first_id === "question5") {
      if (this.state.first === "") {
        this.setState({
          first_id: ""
        });
      } else {
        this.setState({
          first: event.target.value
        });
      }
    } else if (this.state.second_id === "question5") {
      if (this.state.second === "") {
        this.setState({
          second_id: ""
        });
      } else {
        this.setState({
          second: event.target.value
        });
      }
    } else {
      if (this.state.first === "") {
        this.setState({
          first: event.target.value,
          first_id: event.target.id
        });
      } else if (this.state.second === "") {
        this.setState({
          second: event.target.value,
          second_id: event.target.id
        });
      }
    }
  }

  handleSubmit(event) {
    event.preventDefault();
    console.clear();

    console.log();

    // if (this.state.first === "" || this.state.second === "") {
    //   console.log("Choose two questions");
    //   console.log(this.state);
    // } else {
    //   // db.collection(users)
    //   //   .doc(user)
    //   //   .update({
    //   //     questions: {
    //   //       first_question: this.state.first,
    //   //       second_question: this.state.second
    //   //     }
    //   //   });
    // }
  }

  onClick(event) {
    const button_color = document.getElementById(event.target.id).style
      .backgroundColor;

    // if button is grey, so not clicked yet
    if (button_color === "rgb(243, 243, 243)") {
      if (this.state.first === "") {
        this.setState(
          {
            first: event.target.innerText,
            first_id: event.target.id
          },
          () => {
            console.log(this.state);
          }
        );

        // change button color
        document.getElementById(event.target.id).style.backgroundColor =
          "rgb(136, 0, 122)";

        // change text color
        document.getElementById(event.target.id).style.color = "white";
      } else if (this.state.second === "") {
        this.setState(
          {
            second: event.target.innerText,
            second_id: event.target.id
          },
          () => {
            console.log(this.state);
          }
        );

        document.getElementById(event.target.id).style.backgroundColor =
          "rgb(136, 0, 122)";
        document.getElementById(event.target.id).style.color = "white";
      }
    } else {
      // else the button is purple and it's already been selected
      if (this.state.first_id === event.target.id) {
        this.setState(
          {
            first: "",
            first_id: ""
          },
          () => {
            console.log(this.state);
          }
        );

        document.getElementById(event.target.id).style.backgroundColor =
          "rgb(243, 243, 243)";
        document.getElementById(event.target.id).style.color = "black";
      } else if (this.state.second_id === event.target.id) {
        this.setState(
          {
            second: "",
            second_id: ""
          },
          () => {
            console.log(this.state);
          }
        );

        document.getElementById(event.target.id).style.backgroundColor =
          "rgb(243, 243, 243)";
        document.getElementById(event.target.id).style.color = "black";
      }
    }
  }

  render() {
    return (
      <div>
        <p>Pick Two Questions...</p>
        <form className="questions-form" onSubmit={this.handleSubmit}>
          <button
            id="question1"
            className="question-button"
            type="button"
            style={{ backgroundColor: "#f3f3f3" }}
            onClick={this.onClick}
          >
            What is your ideal first date be like?
          </button>

          <button
            id="question2"
            className="question-button"
            type="button"
            style={{ backgroundColor: "#f3f3f3" }}
            onClick={this.onClick}
          >
            If you could meet someone dead or alive, who would it be?
          </button>

          <button
            id="question3 "
            className="question-button"
            type="button"
            style={{ backgroundColor: "#f3f3f3" }}
            onClick={this.onClick}
          >
            What are some misconceptions people have about you?
          </button>

          <button
            id="question4"
            className="question-button"
            type="button"
            style={{ backgroundColor: "#f3f3f3" }}
            onClick={this.onClick}
          >
            What is your ideal place to live and why?
          </button>

          <label>
            Or make your own question...
            <input
              id="question5"
              className="question-text"
              type="text"
              style={{ backgroundColor: "#f3f3f3" }}
              onChange={this.onChange}
            />
          </label>

          <input className="send-button" type="submit" value="Send" />
        </form>
      </div>
    );
  }
}

export default Questions;
